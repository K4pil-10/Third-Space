#include <stdio.h>
int main(){
    int age;
    printf("Enter Age= ");
    scanf("%d", &age);
    if(age>=18){
        if(age>60){
            printf("People is Old age\n");
        }
        else{
            printf("People is Middle Age\n");
        }
        if(age<18){
            printf("People is Junior\n");
        }
        else{
            printf("People is Senior\n");
        }
    }
    return 0;
}