#include <stdio.h>
int main(){
    int age;
    printf("Enter Age= ");
    scanf("%d", &age);
    if(age>=18){
        if(age>=60){
            printf("People is Old age\n");
        }
        else if (age<60){
            printf("People is Middle Age\n");
        }
        else{
            printf("People is Senior");
        }
    }
    return 0;
}