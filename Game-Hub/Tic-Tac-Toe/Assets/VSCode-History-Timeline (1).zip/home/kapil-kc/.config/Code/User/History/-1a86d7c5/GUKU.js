let url= "https://catfact.ninja/fact";
let catFact= document.querySelector(".fact")
let btn= document.querySelector(".btn")
const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON F0RMAT
    let data= await response.json();
    // console.log(data.fact);
   catFact.innerText = (data.fact);
};
   btn.addEventListener= ("click",()=>{
    alert(data.fact);
   });
