
let adj= {
    a:  "Carzy",
    b: "Amazing",
    c: "fire",
}
let shop={
    a: "Engine",
    b: "food",
    c: "Garments",

}

let word ={
    a: "bros",
    b: "Lmited",
    c: "Hub",
}

let random = Math.random();
let first, second, third;

console.log(adj[name])