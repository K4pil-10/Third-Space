// resolve and rejuct are callback provided by JS
let promise = new Promise((resolve, reject)=>{
    resolve("success");
});

console.log(promise);

let pro = new Promise((resolve, reject)=>{
    reject("something is error")

});
console.log(pro);