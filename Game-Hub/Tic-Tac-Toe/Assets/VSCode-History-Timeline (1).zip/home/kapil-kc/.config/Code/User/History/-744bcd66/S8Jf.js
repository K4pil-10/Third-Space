let promise= new promise ((resolve,reject)=>{
    console.log("Hello world");
});