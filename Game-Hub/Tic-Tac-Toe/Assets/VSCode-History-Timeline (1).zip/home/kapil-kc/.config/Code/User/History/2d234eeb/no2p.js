let a= 7;
let b= 10;
console.log("a+b =", a+b);
console.log("a-b =", a-b)
console.log("a%b =", a*c)
try{
    console.log("a%b =", a*c); //error
} catch(err){
    console.log(err);
}
console.log("a*b =", a*b)
console.log("a/b =", a/b)
console.log("a%b =", a%b)