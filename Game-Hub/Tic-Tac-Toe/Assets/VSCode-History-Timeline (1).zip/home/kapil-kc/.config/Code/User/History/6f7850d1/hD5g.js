let a= "Crazy";
let b= "Amazing";
let c= "Fire";
let d= "Engine";
let e= "Foods";
let f="Garments";
let g= "Bros"
let h= "Limited";
let i= "Hub";

const adj ={
let a= "Crazy";
let b= "Amazing";
let c= "Fire";
}