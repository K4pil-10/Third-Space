// resolve and rejuct are already adjust in JS as a function
let promise = new Promise((resolve, reject)=>{
    console.log("I am promise");
    resolve("Hey hello world");
    reject("something is error")

})
console.log(pr)