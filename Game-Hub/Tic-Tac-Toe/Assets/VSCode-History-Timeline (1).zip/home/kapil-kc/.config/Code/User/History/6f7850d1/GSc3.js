
let adj= {
    a:  "Carzy",
    b: "Amazing",
    c: "fire",
}
let shop={
    a: "Engine",
    b: "food",
    c: "Garments",

}

let word ={
    a: "bros",
    b: "Lmited",
    c: "Hub",
}

let random = Math.random();
let first, second, third;

if(random<0.33){
    first= "Crazy";
}
else if(random<0.66 && random>=0.33){
    first ="Amazing"
}
else{
    first= "Fire";
}

if(random<0.33){
    second= "Engine";
}
else if(random<0.66 && random>=0.33){
    second ="Garments"
}
else{
    second= "Food";
}

if(random<0.33){
    third= "Limited";
}
else if(random<0.66 && random>=0.33){
    third ="Bros"
}
else{
    third= "Hub";
}

console.log(first,second,third);