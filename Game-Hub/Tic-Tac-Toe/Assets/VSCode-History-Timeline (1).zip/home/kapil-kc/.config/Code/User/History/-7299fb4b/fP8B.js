function sum(a,b){
    // let sum= a+b;
    console.log(a+b);
}
sum(10,20);

function multiply(c,d){
    return a, b;
}
multiply(10,20);
result = console.log('Multiply of these number is : ');