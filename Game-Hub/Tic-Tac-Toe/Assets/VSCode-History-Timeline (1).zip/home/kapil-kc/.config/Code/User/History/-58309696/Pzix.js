let doller = 20;

if(doller < )