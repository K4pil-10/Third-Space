let a= "Crazy";
let b= "Amazing";
let c= "Fire";
let d= "Engine";
let e= "Foods";
let f="Garments"