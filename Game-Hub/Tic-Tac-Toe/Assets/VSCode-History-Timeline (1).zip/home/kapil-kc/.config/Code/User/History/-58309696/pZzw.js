let doller = 20;

if(doller > 30){
    console.log("CAn buy Web-dev course");
}

else{
    console.log("Can't Buy web-dev course");
}