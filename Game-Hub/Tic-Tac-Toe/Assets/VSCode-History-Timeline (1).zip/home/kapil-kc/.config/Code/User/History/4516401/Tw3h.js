let a= "     hari    ";
console.log(a.trim());

//Trim is used to remove unnecessary white space;