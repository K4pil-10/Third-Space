let subject_num = 7;

const subject_container = document.getElementById("subjects")