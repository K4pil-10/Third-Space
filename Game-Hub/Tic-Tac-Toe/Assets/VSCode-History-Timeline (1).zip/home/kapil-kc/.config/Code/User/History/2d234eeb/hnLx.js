let a= 7;
let b= 10;
console.log("a+b =", a+b);
console.log("a-b =", a-b)
console.log("a%b =", a*c)
console.log("a*b =", a*b)
console.log("a/b =", a/b)
console.log("a%b =", a%b)