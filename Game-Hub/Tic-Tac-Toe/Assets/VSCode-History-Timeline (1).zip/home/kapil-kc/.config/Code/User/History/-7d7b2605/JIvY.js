
// String value can't chaged 
// Array value is easily changed

let num= [1,2,3,4,5,6,7]
console.log(num);
console.log(num.length)
console.log(num[0]);
console.log(num[1]);
console.log(num[2]);
console.log(num[3]);
console.log(num[4]);
console.log(num[5]);
console.log(num[6]);

num[7]= 10;