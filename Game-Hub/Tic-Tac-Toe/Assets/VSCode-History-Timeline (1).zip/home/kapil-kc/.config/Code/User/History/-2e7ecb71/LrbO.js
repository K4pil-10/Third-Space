// resolve and rejuct are already adjust in JS
let name= new names((resolve, reject)=>{
    console.log("I am promise");
    reject("something is error")
})