#include <iostream>
#include <cmath>

using namespace std;

class Armstrong{
    int n;
    public:
    void values(){
        cout <<"Enter a number: ";
        cin >>n;
    }

    int calc(){
        int temp;
        temp =n;
        int digits = 0;
        

    }

};