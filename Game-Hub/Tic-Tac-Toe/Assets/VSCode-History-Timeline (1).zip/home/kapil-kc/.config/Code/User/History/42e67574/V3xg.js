let BASE_URL = "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json";

let dropdowns  = document.querySelectorAll(".dropdown select");

let btn = document.querySelector("form .btn");

let fromCurr = document.querySelector(".from select");

let toCurr = document.querySelector(".to select");

let msg = document.querySelector(".msg");

let swap_btn = document.querySelector(".swap_btn")

for (let select of dropdowns){
    for(let currCode in countryList){
        let newOption = document.createElement("option");
        newOption.innerText = currCode;
        newOption.value= currCode;

        if(select.name ==="from" && currCode ==="USD"){
            newOption.selected= "selected";
        }

        else if(select.name==="to" && currCode === "NPR"){
            newOption.selected= "selected";
        }
        select.append(newOption);
    }

    select.addEventListener("change", (evt)=>{
        changeFlag(evt.target);
    });
}

let changeFlag = (element)=>{
    let currCode = element.value;
    let countrycode = countryList[currCode];
    if (countrycode){
         let flagSrc = ` https://flagsapi.com/${countrycode}/flat/64.png `;
        let img = element.parentElement.querySelector("img");
        img.src = flagSrc; 
    }
};


const updateExchange_Rate = async() =>{
    let amt = document.querySelector(".amt input");
    let amtVal = amt.value;

    if (amtVal === "" || amtVal <1){
        amtVal = 1;
        amt.value = "1";
    }

    let fromVal = fromCurr.value.toLowerCase();
    let toVal = toCurr.value.toLowerCase();

    msg.innerText = ""
}


btn.addEventListener("click", async(evt)=>{
    evt.preventDefault;
    let amt = document.querySelector(".amount , input");
    let amtVal = amt.value;
    if (amtVal ==="" || amtVal <1){
        amtVal=1;
        amt.value = "1";
    }

    const flag = `https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json ${fromCurr.value.toLower()}.json`;
    let response = await fetch(flag);
    let data = await response.json();
    let rate = data[fromCurr.value.toLowerCase()][toCurr.value.toLowerCase()];
    console.log(rate);

    let finalAmt = amtVal * rate;
    msg.innerText = `${amtVal} ${fromCurr.value} = ${finalAmt} ${toCurr.valur}`
});