let url= "https://api.openweathermap.org/data/2.5/weather?q=London&appid=YOUR_KEY";

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON F0RMAT
    let data= await response.json();
    console.log(data);
};
getfacts();
