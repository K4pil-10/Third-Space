let url= "https://jsonplaceholder.typicode.com/posts";

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON F0RMAT
    let data= await response.json();
    console.log(data);
};
getfacts();
