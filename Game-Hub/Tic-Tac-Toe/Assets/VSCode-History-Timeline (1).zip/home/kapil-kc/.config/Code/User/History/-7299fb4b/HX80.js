function sum (a,b){
    let sum= a+b;
    console.log(a+);
}
sum(10,20);