#include <stdio.h>
int main(){
    int age;
    printf("Enter Age= ");
    scanf("%d", &age);
    if(age>= 18){
        printf("People is Senior");
        if(age>60){
            printf("People in Middle age");
        } else if(age>=60){
            printf("People is old age");
        }
        else{
            printf("People is Junior");
        }

        
    }
}