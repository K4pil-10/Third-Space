let money_url = "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json";

let dropdowns  = document.querySelectorAll(".dropdown select");

let btn = document.querySelector("form .btn");

let fromCurr = document.querySelectorAll(".from select");

let toCurr = document.querySelectorAll(".to select");

let msg = document.querySelector(".msg");

for (let select of dropdowns){
    for(currCode in countryList){
        let newOption = document.createElement("option");
        newOption.innerText = currCode;
        newOption.value= currCode;

        if(select.name ==="from" && currCode ==="USD"){
            newOption.selected= "selected";
        }

        else if(select.name==="to" && currCode === "NPR"){
            newOption.selected= "selected";
        }
        select.append(newOption);
    }

    select.addEventListener("change", (evt)=>{
        changeFlag(evt.target);
    });
}

let changeFlag = (element)=>{
    let currCode = element.value;
    let countrycode = countryList(currCode);
    let flagSrc = `https://flagsapi.com/${countrycode}/flat/64.png`;
    let img = element.parentElement.querySelector("img");
    img.src = flagSrc;
}