let subjects = document.getElementById("subjects");

let addSub_btn = document.querySelector(".add_subject_btn");

let calcGpa_btn = document.querySelector(".calc_gpa_btn");

let clearAll_btn = document.querySelector(".clear_all_btn");

let gpa_display = document.getElementById("gpa");

let message = document.getElementById("message");

function get_grade_point(marks){
    if (marks >= 90){
        return 4.00;
    }

    else if (marks >= 80){
        return 3.60;
    }

    else if (marks >= 70){
        return 3.20;
    }

    else if (marks >= 60){
        return 2.80;
    }

    else if (marks >= 50){
        return 2.40;
    }

    else if (marks >= 40){
        return 2.00;
    }

    else if (marks >=35){
        return 1.60;
    }

    else {
        return 0;
    }
}

calcGpa_btn.addEventListener("click", function (){
    let marks_input = document.querySelectorAll(.marks);

    let total_Grade_points = 0;
    let valid_subs = 0;
    let failed = false;
    
    marks_input.forEach(function (input){
        
    })
})