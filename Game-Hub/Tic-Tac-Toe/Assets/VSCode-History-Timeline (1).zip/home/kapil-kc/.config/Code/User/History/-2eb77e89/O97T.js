var words=[
"tree",
"water",
"food",
"house",
"chair",
"table",
"pen",
"school",
"friend",
"happy",
"smile",
"run",
"walk",
"jump",
"play",
"read",
"write",
"sleep",
"eat",
"drink",
"big",
"small",
"fast",
"slow",
"hot",
"cold",
"journey",
"explore",
"discover",
"imagine",
"create",
"design",
"develop",
"improve",
"problem",
"solution",
"challenge",
"success",
"failure",
"effort",
"energy",
"nature",
"culture",
"history",
"future",
"present",
"balance",
"harmony",
"respect",
"courage",
"wisdom",
"freedom",
"justice",
"equality",
"community",
"knowledge",
"education",
"science",
"technology",
"environment",
"communication",
"relationship",
"responsibility",
"opportunity",
"creativity",
"motivation",
"javascript",
"asia",
"nepal",
"buddha",
]

let answer = '';
let maxWrong= 6;
let mistakes= 0;
let guessed= [];
let wordStasus= null;

function randomWord(){
    answer= words[Math.floor(Math.random() * words.length)]
}


function generateButtons(){
    let buttonsHtml= 'abcdefghijklmnopqrstuvwxyz'. split('').map(letter =>
        `<button 
        class="btn btn-lg btn-primary m-2"
        id="${letter}"
        onClick= "handleGuess('${letter}')" >
           ${letter} </button> `) .join('');
        document.getElementById('keyboard').innerHTML= buttonsHtml;
}

function guessWord(){
    wordStasus = answer.split('').map(letter =>(guessed.indexOf(letter)>= 0 ? letter:" _ ")) .join('');
    document.getElementById('wordSpotlight'). innerHTML = wordStasus
}

function handleGuess(chosenletter){
    guessed.indexOf(chosenletter === -1 ? guessed.push(chosenletter) : null );
     document.getElementById(chosenletter).setAttribute('disabled', true);

     if (answer.indexOf(chosenletter) >= 0){
        guessWord();
     }
}

document.getElementById('maxWrong'). innerHTML= maxWrong;

randomWord();
generateButtons();
guessWord();