#include <stdio.h>
int main(){
    int age;
    printf("Enter Age= ");
    scanf("%d", &age);
    if (age >=18){
         if(age>=60){
            printf("People is OLd AGE");
        }
        else("People is MIddle AGE");
    }
    
}