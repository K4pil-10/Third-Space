// resolve and rejuct are already adjust in JS

let promises= new Promises((resolve, reject)=>{
resolve(123);
})