let a= "Crazy";
let b= "Amazing";
let c= "Fire";
let d= "Engine";
let e= "Foods";
let f="Garments";
let g= "Bros"
let h= "Limited";
let i= "Hub";

let adj= {
    a:  "Carzy",
    b: "Amazing",
    c: "fire",
}
let shop={
    a: "Engine",
    b: "food",
    c: "Garments",

}

let 