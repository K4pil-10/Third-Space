let promise= new Promise((resolve,reject)=>{
    console.log("Hello world");
});