let url= "https://prasoonkandel.com/";

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON FORMAT
};
