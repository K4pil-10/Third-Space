const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreUI = document.getElementById("score");
const oxygenUI = document.getElementById("oxygen");

let score = 0;
let oxygen = 100;

const keys = {};

document.addEventListener("keydown", e => keys[e.key] = true);
document.addEventListener("keyup", e => keys[e.key] = false);

const diverImg = new Image();
diverImg.src = "assets/diver.png";

const treasureImg = new Image();
treasureImg.src = "assets/treasure.png";

const monsterImg = new Image();
monsterImg.src = "assets/monster.png";

const bgImg = new Image();
bgImg.src = "assets/background.png";

class Player{
constructor(){
this.x = 100;
this.y = 200;
this.width = 60;
this.height = 60;
this.speed = 4;
}

update(){

if(keys["ArrowRight"]) this.x += this.speed;
if(keys["ArrowLeft"]) this.x -= this.speed;
if(keys["ArrowUp"]) this.y -= this.speed;
if(keys["ArrowDown"]) this.y += this.speed;

this.x = Math.max(0, Math.min(canvas.width - this.width, this.x));
this.y = Math.max(0, Math.min(canvas.height - this.height, this.y));
}

draw(){
ctx.drawImage(diverImg,this.x,this.y,this.width,this.height);
}
}

class Treasure{
constructor(){
this.x = canvas.width + Math.random()*500;
this.y = Math.random()*450;
this.size = 40;
this.speed = 2;
}

update(){
this.x -= this.speed;
}

draw(){
ctx.drawImage(treasureImg,this.x,this.y,this.size,this.size);
}
}

class Monster{
constructor(){
this.x = canvas.width + Math.random()*500;
this.y = Math.random()*450;
this.size = 70;
this.speed = 3;
}

update(){
this.x -= this.speed;
}

draw(){
ctx.drawImage(monsterImg,this.x,this.y,this.size,this.size);
}
}

const player = new Player();

let treasures = [];
let monsters = [];

function spawnObjects(){

if(Math.random() < 0.02){
treasures.push(new Treasure());
}

if(Math.random() < 0.01){
monsters.push(new Monster());
}

}

function collision(a,b){

return a.x < b.x + b.size &&
a.x + a.width > b.x &&
a.y < b.y + b.size &&
a.y + a.height > b.y;

}

function update(){

player.update();

spawnObjects();

treasures.forEach((t,i)=>{
t.update();

if(collision(player,t)){
score += 10;
treasures.splice(i,1);
}

});

monsters.forEach((m,i)=>{
m.update();

if(collision(player,m)){
oxygen -= 20;
monsters.splice(i,1);
}

});

oxygen -= 0.03;

scoreUI.textContent = Math.floor(score);
oxygenUI.textContent = Math.floor(oxygen);

if(oxygen <= 0){
alert("Game Over! Score: " + score);
document.location.reload();
}

}

function draw(){

ctx.clearRect(0,0,canvas.width,canvas.height);

ctx.drawImage(bgImg,0,0,canvas.width,canvas.height);

player.draw();

treasures.forEach(t => t.draw());
monsters.forEach(m => m.draw());

}

function gameLoop(){

update();
draw();

requestAnimationFrame(gameLoop);
}

gameLoop();