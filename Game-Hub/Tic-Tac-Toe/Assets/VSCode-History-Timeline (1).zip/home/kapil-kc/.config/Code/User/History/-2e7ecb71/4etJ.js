// resolve and rejuct are already adjust in JS as a function
let promise = new Promise((resolve, reject)=>{
    resolve("sucess");
});

console.log(promise);

let pro = new Promise((resolve, reject)=>{
    reject("something is error")

});
console.log(pro);