function sum (a,b){
    console.log(`Sum of ${a} + ${b} = ${sum}`);
}
sum(10,20);