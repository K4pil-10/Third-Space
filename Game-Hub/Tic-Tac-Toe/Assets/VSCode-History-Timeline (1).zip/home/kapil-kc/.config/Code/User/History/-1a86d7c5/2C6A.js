let url= "https://catfact.ninja/fact";
let catFact= document.querySelector("#fact")

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON F0RMAT
    let data= await response.json();
   catFact.innerText = (data.fact);
};
getfacts();
