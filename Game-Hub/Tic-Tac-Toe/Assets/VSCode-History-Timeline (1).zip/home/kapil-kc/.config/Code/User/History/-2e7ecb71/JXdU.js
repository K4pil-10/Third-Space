// resolve and rejuct are already adjust in JS

let promises=((resolve, reject)=>{
resolve(123);
})