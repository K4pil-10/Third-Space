let a= "     hari    ";
console.log(a.trim());
console.log(a)

//Trim is used to remove unnecessary white space;