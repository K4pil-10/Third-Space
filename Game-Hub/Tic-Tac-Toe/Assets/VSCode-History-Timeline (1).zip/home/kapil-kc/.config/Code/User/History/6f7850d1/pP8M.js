
let adj= {
    a:  "Carzy",
    b: "Amazing",
    c: "fire",
}
let shop={
    a: "Engine",
    b: "food",
    c: "Garments",

}

let word ={
    a: "bros",
    b: "Lmited",
    c: "Hub",
}

let random = Math.random();
let first, second, third;

if(random<0.33){
    first= "Crazy";
}
else if(random>0.33 && random  >=0.66){
    
}