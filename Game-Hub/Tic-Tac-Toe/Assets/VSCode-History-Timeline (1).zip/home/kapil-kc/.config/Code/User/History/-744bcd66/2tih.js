let promise = new promise((resolve, reject=>{
    console.log("Hey its promise");
})