// resolve and rejuct are already adjust in JS
let promise = new Promise((resolve, reject)=>{
    console.log("I am promise");
    reject("something is error")
})