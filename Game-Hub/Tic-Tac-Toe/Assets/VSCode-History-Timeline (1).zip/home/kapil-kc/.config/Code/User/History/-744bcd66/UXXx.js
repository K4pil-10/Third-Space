// Promise types:
// 1. Pending
// 2. Resolve(accept) 
// 3. Rejected

let promise= new Promise((resolve,reject)=>{
    console.log("Hello world");
});
promise();