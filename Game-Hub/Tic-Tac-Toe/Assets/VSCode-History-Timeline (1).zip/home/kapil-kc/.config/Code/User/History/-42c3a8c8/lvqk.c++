#include <iostream>
#include <cmath>

using namespace std;

class Armstrong{
    int n;
    public:
    void values(){
        cout <<"Enter a number: "; // 143
        cin >>n;
    }

    int calc(){
        int temp;
        temp =n;
        int digits = 0;
        int sum = 0;
        int last_digits;

        while (temp > 0){
            digits = digits +1; // 1, 2, 3
            temp= temp/10;  // 14, 1
        }

        while( temp > 0){
            last_digits= temp %10; // 4, 3, 1
            sum= pow(last_digits, digits); // 4^3, 3^3, 
            temp = temp /10; // 14, 1
        }

        if(n == sum){
            cout<<sum<<" is Arstrong";
        }

        else{
            cout <<sum <<" isn't Armstrong";
        }

    }

};

int main(){
    Armstrong obj;
    obj.value();
    obj.calc();
    return 0;
}