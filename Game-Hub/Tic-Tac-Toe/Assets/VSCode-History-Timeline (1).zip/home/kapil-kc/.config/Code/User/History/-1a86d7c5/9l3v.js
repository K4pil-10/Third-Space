let url= "https://cat-fact.herokuapp.com/facts";

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON FORMAT
};
getfacts();