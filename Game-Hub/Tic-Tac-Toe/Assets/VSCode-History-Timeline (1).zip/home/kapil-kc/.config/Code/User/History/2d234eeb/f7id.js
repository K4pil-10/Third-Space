let a= 7;
let b= 10;
console.log("");
console.log("")
console.log("")
console.log("")
console.log("")
console.log("")
console.log("")