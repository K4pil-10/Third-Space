let url= "https://prasoonkandel.com/";
fetch(url);
console.log()