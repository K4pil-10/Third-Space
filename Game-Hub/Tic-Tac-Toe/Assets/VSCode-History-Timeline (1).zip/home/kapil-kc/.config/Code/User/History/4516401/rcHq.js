let a= "     hari    ";
console.log(a.trim())