let url= "https://hackatime.hackclub.com/?interval=today;

const getfacts= async()=>{
    console.log("getting data...");
    let response= await fetch(url);
    console.log(response); // JASON FORMAT
};