// Promise types:
// 1. Pending
// 2. fulfuiled 

let promise= new Promise((resolve,reject)=>{
    console.log("Hello world");
});