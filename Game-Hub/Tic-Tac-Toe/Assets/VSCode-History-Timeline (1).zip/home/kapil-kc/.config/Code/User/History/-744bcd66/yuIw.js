// Promise types:
// 1. Pending
// 2. Resolve(accept) 
// 3. Rejected
//  resolve and rejected are function in Js.
let promise= new Promise((resolve,reject)=>{
    console.log("Hello world 2A");
    resolve("success");
});
let pro= new Promise((resolve,reject)=>{
    console.log("Hello world 2R");
    reject("sorry");
});
