let url= "https://prasoonkandel.com/";
let promise= fetch(url);
console.log(promise);