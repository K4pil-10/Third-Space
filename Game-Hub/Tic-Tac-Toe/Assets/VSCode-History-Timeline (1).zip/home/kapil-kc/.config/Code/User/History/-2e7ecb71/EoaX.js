// resolve and rejuct are already adjust in JS
let promise = new Promise((resolve, reject)=>{
    console.log("I am promise");
    resolve(123)
    reject("something is error")

})