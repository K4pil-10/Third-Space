var words=[
"tree",
"water",
"food",
"house",
"chair",
"table",
"pen",
"school",
"friend",
"happy",
"smile",
"run",
"walk",
"jump",
"play",
"read",
"write",
"sleep",
"eat",
"drink",
"big",
"small",
"fast",
"slow",
"hot",
"cold",
"journey",
"explore",
"discover",
"imagine",
"create",
"design",
"develop",
"improve",
"problem",
"solution",
"challenge",
"success",
"failure",
"effort",
"energy",
"nature",
"culture",
"history",
"future",
"present",
"balance",
"harmony",
"respect",
"courage",
"wisdom",
"freedom",
"justice",
"equality",
"community",
"knowledge",
"education",
"science",
"technology",
"environment",
"communication",
"relationship",
"responsibility",
"opportunity",
"creativity",
"motivation",
"javascript",
"asia",
"nepal",
"buddha",
]

let answer = '';
let maxWrong= 6;
let mistakes= 0;
let guessed= [];
let wordStatus= null;

function randomWord(){
    answer= words[Math.floor(Math.random() * words.length)]
}


function generateButtons(){
    let buttonsHtml= 'abcdefghijklmnopqrstuvwxyz'. split('').map(letter =>
        `<button 
        class="btn btn-lg btn-primary m-2"
        id="${letter}"
        onClick= "handleGuess('${letter}')" >
           ${letter} </button> `) .join('');
        document.getElementById('keyboard').innerHTML= buttonsHtml;
}

function guessWord(){
    wordStatus = answer.split('').map(letter =>(guessed.indexOf(letter)>= 0 ? letter:" _ ")) .join('');
    document.getElementById('wordSpotlight').innerHTML = wordStatus
}

function handleGuess(chosenletter){
if (guessed.indexOf(chosenletter) === -1) {
    guessed.push(chosenletter);
}
     document.getElementById(chosenletter).setAttribute('disabled', true);
    // alert(answer);
     if (answer.indexOf(chosenletter) >= 0){
        guessWord();
        checkIfGameWon();
     } 
     else if(answer.indexOf(chosenletter) === -1){
        mistakes++;
        updateMistakes();
        checkIfGameLost();
        updateHangmanPic();
     }
}

function updateHangmanPic(){
document.getElementById('hangmanPic').src = './Images/' + mistakes + '.jpg';
}

function checkIfGameWon(){
    if(wordStatus === answer){
        document.getElementById('keyboard').innerHTML= 'You Won Congartulation !'
    }
} 

function checkIfGameLost(){
    if(mistakes === maxWrong){
        document.getElementById('wordSpotlight').innerHTML = 'The answer was: ' + answer;
        document.getElementById('keyboard').innerHTML= 'You Lost Try Again !'
    }
} 

function updateMistakes(){
    document.getElementById('mistakes').innerHTML = mistakes;
}


document.getElementById('maxWrong'). innerHTML= maxWrong;

randomWord();
generateButtons();
guessWord();

function reset(){
    mistakes= 0;
    guessed= [];
    document.getElementById('hangmanPic').scr= "./Images/0.jpg";
    randomWord();
    guessWord();
    updateMistakes();
    generateButtons();
}
