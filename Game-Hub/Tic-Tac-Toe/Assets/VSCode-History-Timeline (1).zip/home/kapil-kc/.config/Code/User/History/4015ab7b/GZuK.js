let std={
    name: "Kapil Bahadur Chhetri",
    grade: 9,
    learning: "JavaScript",
    favGame: "football",
}
console.log(std)