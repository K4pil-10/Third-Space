#include <stdio.h>
int main(){
    int age;
    printf("Enter Age= ");
    scanf("%d", &age);
    if(age>=18){
        if(age>=60){
            printf("People is Middle age");
        }
        else{
            printf("People is Old Age");
        }
    }
    else{
        if(age<18){
            printf("People is Junior");
        }
        else{
            
        }
    }
}