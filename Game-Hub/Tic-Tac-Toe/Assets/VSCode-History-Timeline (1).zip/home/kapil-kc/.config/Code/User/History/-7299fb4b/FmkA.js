function sum(a,b){
    // let sum= a+b;
    console.log(a+b);
}
sum(10,20);

function multiply(c,d){
    return c * d;
}
result = multiply(10,20);
result = console.log('Multiply of these number is : ', result);